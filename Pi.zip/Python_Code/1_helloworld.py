#!/usr/bin/python
#Print Hello world
print "Hello World!"