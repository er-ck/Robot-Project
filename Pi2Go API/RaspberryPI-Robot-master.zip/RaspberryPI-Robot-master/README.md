This is Carmel College's edit of this project that was started by www.theraspberrypiguy.com

Aim's of this project are:

1. An intuitive GUI to control the movement of the robot. In the forward, reverse, left and right direction.
2. i) Real-time display of distance of nearest object using the sonar sensor.
   ii) Real-time display of state of each infrared sensor.
3. Using data from 2:
   i) Generate a visual warning of any possible collision.
   ii) On/off automatic obstacle avoidance movement.
4. Control from a webpage (apache server).
5. i) Control movement of attached video camera.
   ii) Real-time stream from the attached video camera in GUI.


Project leader:
Michael 

The programmers in this project are:
Erick Musembi, Brian and Thomas Mason.

Tester:
Josh

