#!/bin/sh
python -m webiopi $*
